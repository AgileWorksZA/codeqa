"""CodeQA - Code Quality Metrics Tracking Tool."""

__version__ = "0.1.11"